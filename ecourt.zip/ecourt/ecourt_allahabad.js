const request = require('request')
const cheerio = require('cheerio')

request(
  'http://127.0.0.1:5500/web_pages/ecourt_allahabad2021.html',
  (error, response, html) => {
    if (!error && response.statusCode == 200) {
      // console.log(html)
      const $ = cheerio.load(html)

      // WPIL
      let Filing_no = $(
        // Below Data code belong to year 2020
        // #printpanel > div:nth-child(3) > table > tbody > tr:nth-child(1) > td:nth-child(2)
        // Below Data code belong to year 2021
        '#printpanel > div:nth-child(3) > table > tbody > tr:nth-child(2) > td:nth-child(2)'
      ).text()
      let CNR = $(
        // '#printpanel > div:nth-child(3) > table > tbody > tr:nth-child(2) > td:nth-child(2) > strong'
        '#printpanel > div:nth-child(3) > table > tbody > tr:nth-child(2) > td:nth-child(3)'
      ).text()

      let Filing_date = $(
        // '#printpanel > div:nth-child(3) > table > tbody > tr:nth-child(1) > td:nth-child(3)'
        '#printpanel > div:nth-child(3) > table > tbody > tr:nth-child(2) > td:nth-child(3)'
      )
        .text()
        .replace(/Filing Date : /, '')
      // let Filing_date = Filing_date_replace.replace('Filing Date : ', '')

      let Date_Of_Registration = $(
        '#printpanel > div:nth-child(3) > table > tbody > tr:nth-child(2) > td:nth-child(3)'
      )
        .text()
        .replace(/Date of Registration : /, '')
      // let Date_Of_Registration = DOR.replace('Date of Registration : ', '')

      let wpilKey = {
        Filing_no,
        CNR,
        Filing_date,
        Date_Of_Registration,
      }

      // console.log(Filing_no)
      // console.log(CNR)
      // console.log(Filing_date)
      // console.log(Date_Of_Registration)

      // Case Status Value sccrap ===============================================================================

      let First_Hearing_Date = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(1) > td'
      ).text()
      let Date_of_Decision = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(2) > td'
      ).text()
      let Case_Status = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(3) > td'
      ).text()
      let Nature_of_Disposal = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(4) > td'
      ).text()
      let Stage_of_Case = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(5) > td'
      ).text()
      let Coram = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(6) > td'
      )
        .text()
        .trim()
      let Bench_Type = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(7) > td'
      ).text()
      let Judicial_Branch = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(8) > td'
      ).text()
      let Causelist_Type = $(
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(9) > td'
      ).text()
      let State = $(
        // '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(10) > td'
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(8) > td'
      ).text()
      let District = $(
        // '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(11) > td'
        '#printpanel > div:nth-child(5) > table > tbody > tr:nth-child(9) > td'
      ).text()

      let caseStatus = {
        First_Hearing_Date,
        Date_of_Decision,
        Case_Status,
        Nature_of_Disposal,
        Stage_of_Case,
        Coram,
        Bench_Type,
        Judicial_Branch,
        Causelist_Type,
        State,
        District,
      }

      // Petitioner/Respondent and their Advocate(s) Values...
      let Petitioner = $(
        '#printpanel > div:nth-child(7) > table > tbody > tr > td:nth-child(2)'
      )
        .text()
        .replace(/\n/g, '')
        .trim()
      let Respondent = $(
        '#printpanel > div:nth-child(7) > table > tbody > tr > td:nth-child(2)'
      )
        .text()
        .replace(/\n/g, '')
        .trim()
      let Advocate = {
        Petitioner,
        Respondent,
      }

      // Category Details Values...
      let Category = $(
        '#printpanel > div:nth-child(9) > table > tbody > tr:nth-child(1) > td'
      ).text()
      let Sub_Category = $(
        '#printpanel > div:nth-child(9) > table > tbody > tr:nth-child(2) > td'
      ).text()
      let categoryDetails = {
        Category,
        Sub_Category,
      }

      // IA Details
      let Application_Number = $(
        '#printpanel > div:nth-child(11) > table > tbody > tr > td:nth-child(1)'
      )
        .text()
        .replace(/\n/g, '')
        .trim()
      Application_Number = Application_Number.split(' I')

      let Party = $(
        '#printpanel > div:nth-child(11) > table > tbody > tr > td:nth-child(2)'
      )
        .text()
        .replace(/\n/g, '')
        .trim()
      let Date_of_Filing = $(
        '#printpanel > div:nth-child(11) > table > tbody > tr > td:nth-child(3)'
      ).text()
      let Next_Disposal_Date = $(
        '#printpanel > div:nth-child(11) > table > tbody > tr > td:nth-child(4)'
      ).text()
      let IA_Status = $(
        '#printpanel > div:nth-child(11) > table > tbody > tr > td:nth-child(5)'
      ).text()
      let IA_Details = {
        Application_Number,
        Party,
        Date_of_Filing,
        Next_Disposal_Date,
        IA_Status,
      }

      // Last Listing Detail
      let Cause_List_Type = $(
        '#printpanel > div:nth-child(13) > table > tbody > tr > td:nth-child(1)'
      ).text()
      let Dr_Justice = $(
        '#printpanel > div:nth-child(13) > table > tbody > tr > td:nth-child(2)'
      )
        .text()
        .replace(/\n/g, '')
        .trim()
      let Last_Listing_Date = $(
        '#printpanel > div:nth-child(13) > table > tbody > tr > td:nth-child(3)'
      ).text()
      let Stage_of_Listing = $(
        '#printpanel > div:nth-child(13) > table > tbody > tr > td:nth-child(4)'
      ).text()
      let Last_Short_Order = $(
        '#printpanel > div:nth-child(13) > table > tbody > tr > td:nth-child(5)'
      ).text()

      let lastListingDetails = {
        Cause_List_Type,
        Dr_Justice,
        Last_Listing_Date,
        Stage_of_Listing,
        Last_Short_Order,
      }

      console.log(wpilKey)
      console.log('=================== Case Status ====================')
      console.log(caseStatus)
      console.log(
        '======== Petitioner/Respondent and their Advocate(s) Values ======'
      )
      console.log(Advocate)
      console.log('======== Category Details Value ======')
      console.log(categoryDetails)
      console.log('============== IA Details ============')
      console.log(IA_Details)
      console.log('========= Last Listing Details =======')
      console.log(lastListingDetails)
    }
  }
)
