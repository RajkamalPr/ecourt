// console.log('testing')
const request = require('request-promise')
const cheerio = require('cheerio')
// const fs = require(fs)
// const json2csv = require('json2csv').Parser
// const { response } = require('express')
// const { html } = require('cheerio/lib/api/manipulation')

function page_scrap() {
  const amazon = 'https://www.amazon.com/s?rh=n%3A1&fs=true&ref=lp_1_sar'
  ;(async () => {
    let products = []
    const response = await request({
      uri: amazon,
      headers: {
        accept:
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9',
      },
      gzip: true,
    })
    let links
    let $ = cheerio.load(response)
    for (let i = 0; i < 17; i++) {
      let title = $(
        '#search > div.s-desktop-width-max.s-opposite-dir > div > div.s-matching-dir.sg-col-16-of-20.sg-col.sg-col-8-of-12.sg-col-12-of-16 > div > span:nth-child(4) > div.s-main-slot.s-result-list.s-search-results.sg-row > div:nth-child(' +
          i +
          ') > div > span > div > div > div:nth-child(2) > div.sg-col.sg-col-4-of-12.sg-col-8-of-16.sg-col-12-of-20 > div > div > div:nth-child(1) > h2 > a '
      ).attr('href')
      console.log(title)
      links = title
      console.log('===================================================')
      return product_scrap(links)
    }

    /*products.push({
    title,
    author,
    rating,
    price,
  })*/
  })()
}

// product_scrap()
page_scrap()

function product_scrap(links) {
  const amazon = `https://www.amazon.com${links}`

  ;(async () => {
    let products = []
    const response = await request({
      uri: amazon,
      headers: {
        accept:
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9',
      },
      gzip: true,
    })

    let $ = cheerio.load(response)
    let title = $('#productTitle').text()
    let author = $(
      '#bylineInfo > span > span.a-declarative > a.a-link-normal.contributorNameID'
    ).text()
    let rating = $(
      '#acrPopover > span.a-declarative > a > i.a-icon.a-icon-star.a-star-5 > span'
    ).text()
    let price = $('#a-autoid-10-announce > span.a-color-base > span').text()
    console.log('Title : ' + title)
    console.log('Author : ' + author)
    console.log('Rating : ' + rating)
    console.log('Price : ' + price)
    console.log('==============End================')
    /*products.push({
    title,
    author,
    rating,
    price,
  })*/
  })()
}
