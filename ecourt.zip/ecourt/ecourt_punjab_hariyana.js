const request = require('request')
const cheerio = require('cheerio')

request(
  'http://127.0.0.1:5500/web_pages/ecourt_punjab&hariyana.html',
  (error, response, html) => {
    if (!error && response.statusCode == 200) {
      // console.log(html)
      const $ = cheerio.load(html)

      // CWP-PIL-2-2021

      let Diary_Number = $(
        '#table1 > tbody > tr:nth-child(5) > td:nth-child(2)'
      ).text()
      let District = $(
        '#table1 > tbody > tr:nth-child(5) > td:nth-child(4)'
      ).text()
      let Category = $('#table1 > tbody > tr:nth-child(6) > td:nth-child(2)')
        .text()
        .replace(/\n/g, '')
        .trim()
      let Main_Case_Detail = $(
        '#table1 > tbody > tr:nth-child(6) > td:nth-child(4)'
      ).text()
      let Party_Detail = $('#table1 > tbody > tr:nth-child(7) > td.data_item')
        .text()
        .replace(/\n/g, '')
        .trim()
      let Advocate_Name = $(
        '#table1 > tbody > tr:nth-child(8) > td:nth-child(2)'
      )
        .text()
        .replace(/\n/g, '')
        .trim()
      let List_Type = $(
        '#table1 > tbody > tr:nth-child(8) > td:nth-child(4)'
      ).text()
      let Status = $('#table1 > tbody > tr:nth-child(9) > td.data_item')
        .text()
        .replace(/\n/g, '')
        .trim()

      let CWP_PIL = {
        Diary_Number,
        District,
        Category,
        Main_Case_Detail,
        Party_Detail,
        Advocate_Name,
        List_Type,
        Status,
      }

      // Case Listing Details ======================================================================

      let Cause_List_Date = $(
        '#table1 > tbody > tr:nth-child(13) > td:nth-child(1)'
      ).text()
      let List_Type_Sr_No = $(
        '#table1 > tbody > tr:nth-child(13) > td:nth-child(2)'
      ).text()
      let Case_Bench = $('#table1 > tbody > tr:nth-child(13) > td:nth-child(3)')
        .text()
        .replace(/\n/g, '')
        .trim()
      let Order_Link = $(
        '#table1 > tbody > tr:nth-child(13) > td:nth-child(4)'
      ).text()

      let Case_Listing_Details = {
        Cause_List_Date,
        List_Type_Sr_No,
        Case_Bench,
        Order_Link,
      }

      // Judgment Details =======================================================================

      let Order_Date = $('#table1 > tbody > tr.alt > td:nth-child(1)').text()
      let Order_Type = $('#table1 > tbody > tr.alt > td:nth-child(2)').text()
      let Judgment_Bench = $('#table1 > tbody > tr.alt > td:nth-child(3)')
        .text()
        .replace(/\n/g, '')
        .trim()
      let Judgment_Link = $(
        '#table1 > tbody > tr.alt > td:nth-child(4) > a'
      ).text()

      let Judgment_Details = {
        Order_Date,
        Order_Type,
        Judgment_Bench,
        Judgment_Link,
      }
      console.log(CWP_PIL)
      console.log('========== Case Listing Details ==========')
      console.log(Case_Listing_Details)
      console.log('========== Judgment Details ==========')
      console.log(Judgment_Details)
    }
  }
)
