const request = require('request')
const cheerio = require('cheerio')

request(
  'http://127.0.0.1:5500/web_pages/ecourt_calcutta.html',
  (error, response, html) => {
    if (!error && response.statusCode == 200) {
      // console.log(html)
      const $ = cheerio.load(html)

      // WPIL
      let Case_Type = $(
        '#secondpage > div:nth-child(13) > div:nth-child(5) > span:nth-child(2)'
      ).text()
      Case_Type = Case_Type.replace('Case Type :', '')

      // Filing_Number_split start...
      let Filing_Number = $(
        '#secondpage > div:nth-child(13) > div:nth-child(5) > span:nth-child(4)'
      ).text()
      Filing_Number = Filing_Number.replace('Filing Number:', '')
      Filing_Number = Filing_Number.split('F')
      Filing_Number = Filing_Number[0]
      // Filing_Number = Filing_Number.replace('Filing Date: 10-02-2021', '')
      // Filing_Number_split End...

      let Filing_Date = $(
        '#secondpage > div:nth-child(13) > div:nth-child(5) > span:nth-child(4) > span:nth-child(2)'
      ).text()
      Filing_Date = Filing_Date.replace('Filing Date:', '')

      let Registration_Number = $(
        '#secondpage > div:nth-child(13) > div:nth-child(5) > span:nth-child(6) > label'
      )
        .text()
        .replace(':', '')

      let Registration_Date = $(
        '#secondpage > div:nth-child(13) > div:nth-child(5) > span:nth-child(6) > span:nth-child(3) > label:nth-child(2)'
      )
        .text()
        .replace(':', '')

      let CNR_Number = $(
        '#secondpage > div:nth-child(13) > div:nth-child(5) > b > span'
      )
        .text()
        .replace('CNR Number:', '')

      let wpilKey = {
        Case_Type,
        Filing_Number,
        Filing_Date,
        Registration_Number,
        Registration_Date,
        CNR_Number,
      }
      // let Filing_Number = Filing_Number_split.replace(/Filing Date/, '')

      // Case Status =======================================================================================

      let First_Hearing_Date = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(1) > label'
      )
        .text()
        .replace('First Hearing Date :', '')

      let Decision_Date = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(3) > label > strong:nth-child(2)'
      )
        .text()
        .replace(':', '')

      let Case_Status = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(5) > label > strong:nth-child(2)'
      ).text()

      let Nature_of_Disposal = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(7) > label > strong:nth-child(2)'
      ).text()

      let Coram = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(9) > label > strong:nth-child(2)'
      )
        .text()
        .replace(':', '')
        .trim()
      Coram = Coram.replace('\n', '')

      let Bench = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(10) > label > strong:nth-child(2)'
      )
        .text()
        .replace(':', '')
        .trim()

      let State = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(11) > label > strong:nth-child(2)'
      )
        .text()
        .trim()

      let District = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(12) > label > strong:nth-child(2)'
      )
        .text()
        .replace(':', '')
        .trim()

      let Judicial = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(13) > label > strong:nth-child(2)'
      )
        .text()
        .replace(':', '')
        .trim()

      let Causelist_Name = $(
        '#secondpage > div:nth-child(13) > div:nth-child(8) > span:nth-child(14) > label > strong:nth-child(2)'
      )
        .text()
        .replace(':', '')
        .trim()
      // Above Code need to Change...

      let caseStatus = {
        First_Hearing_Date,
        Decision_Date,
        Case_Status,
        Nature_of_Disposal,
        Coram,
        Bench,
        State,
        District,
        Judicial,
        Causelist_Name,
      }

      // Petitioner and Advocate ==============================================================
      let Petitioner_and_Advocate = $(
        '#secondpage > div:nth-child(13) > div:nth-child(10) > span.Petitioner_Advocate_table'
      )
        .text()
        .replace('\n', '')
        .trim()

      let petitionerAndAdvocate = {
        Petitioner_and_Advocate,
      }

      // Respondent and Advocate =============================================================

      let Respondent_and_Advocate = $(
        '#secondpage > div:nth-child(13) > div:nth-child(10) > span.Respondent_Advocate_table'
      )
        .text()
        .trim()
      let respondentAndAdvocate = {
        Respondent_and_Advocate,
      }

      // Acts =================================================================================

      let actsCountRow = $('#act_table > tbody > tr').length
      let actsArray = []
      for (let i = 2; i <= actsCountRow; i++) {
        let Under_Act = $(
          `#act_table > tbody > tr:nth-child(${i}) > td:nth-child(1)`
        )
          .text()
          .trim()
        let Under_Section = $(
          `#act_table > tbody > tr:nth-child(${i}) > td:nth-child(2)`
        )
          .text()
          .trim()

        let actsObjects = {
          Under_Act,
          Under_Section,
        }
        actsArray.push(actsObjects)
      }

      // History of Case Hearing =============================================================

      let historyCasehearingCount = $(
        '#secondpage > div:nth-child(13) > table.history_table > tbody > tr'
      ).length

      let historyCasehearing = []

      for (let i = 2; i <= historyCasehearingCount; i++) {
        let causeListType = $(
          `#secondpage > div:nth-child(13) > table.history_table > tbody > tr:nth-child(${i}) > td:nth-child(1)`
        )
          .text()
          .trim()

        let judge = $(
          `#secondpage > div:nth-child(13) > table.history_table > tbody > tr:nth-child(${i}) > td:nth-child(2)`
        )
          .text()
          .trim()

        let businessOnDate = $(
          `#secondpage > div:nth-child(13) > table.history_table > tbody > tr:nth-child(${i}) > td:nth-child(3)`
        )
          .text()
          .trim()
        let hearingDate = $(
          `#secondpage > div:nth-child(13) > table.history_table > tbody > tr:nth-child(${i}) > td:nth-child(4)`
        )
          .text()
          .trim()
        let purposeOfHearing = $(
          `#secondpage > div:nth-child(13) > table.history_table > tbody > tr:nth-child(${i}) > td:nth-child(5)`
        )
          .text()
          .trim()

        let historyCasehearingObject = {
          causeListType,
          judge,
          businessOnDate,
          hearingDate,
          purposeOfHearing,
        }
        historyCasehearing.push(historyCasehearingObject)
      }

      // Orders ===============================================================================================

      let orderRowCount = $(
        '#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr'
      ).length
      let OrderArray = []
      for (let i = 2; i <= orderRowCount; i++) {
        let Order_Number = $(
          `#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(${i}) > td:nth-child(1)`
        )
          .text()
          .trim()
        let Judge = $(
          // `#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(${i}) > td:nth-child(2)`
          `#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(${i}) > td:nth-child(2) > font`
          // #secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(2) > td:nth-child(2) > font
        )
          .text()
          .trim()
        let Order_Date = $(
          `#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(${i}) > td:nth-child(3)`
        )
          .text()
          .trim()
        let Order_Details = $(
          `#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(${i}) > td:nth-child(4) > a > font`
          // `#secondpage > div:nth-child(13) > table:nth-child(16) > tbody > tr:nth-child(2) > td:nth-child(4) > a > font`
        )
          .text()
          .trim()

        let orderObject = {
          Order_Number,
          Judge,
          Order_Date,
          Order_Details,
        }
        OrderArray.push(orderObject)
      }

      // OBJECTION ======================================================================================================

      let objectionRowCount = $(
        '#secondpage > div:nth-child(13) > table:nth-child(18) > tbody > tr'
      ).length

      let ObjectionArray = []
      for (let i = 2; i <= objectionRowCount; i++) {
        let Sr_No = $(
          `#secondpage > div:nth-child(13) > table:nth-child(18) > tbody > tr:nth-child(${i}) > td:nth-child(1) > b`
        ).text()
        let Scrutiny_Date = $(
          `#secondpage > div:nth-child(13) > table:nth-child(18) > tbody > tr:nth-child(${i}) > td:nth-child(2)`
        ).text()
        let OBJECTION = $(
          `#secondpage > div:nth-child(13) > table:nth-child(18) > tbody > tr:nth-child(${i}) > td:nth-child(3) > b`
        ).text()
        let Compliance_Date = $(
          `#secondpage > div:nth-child(13) > table:nth-child(18) > tbody > tr:nth-child(${i}) > td:nth-child(4)`
        ).text()
        let Receipt_Date = $(
          `#secondpage > div:nth-child(13) > table:nth-child(18) > tbody > tr:nth-child(${i}) > td:nth-child(5)`
        ).text()

        ObjectionObject = {
          Sr_No,
          Scrutiny_Date,
          OBJECTION,
          Compliance_Date,
          Receipt_Date,
        }

        ObjectionArray.push(ObjectionObject)
      }

      // Document Details =========================================================================================

      let documentDetailsRowCount = $(
        '#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr'
      ).length

      let documentArray = []
      for (let i = 2; i <= documentDetailsRowCount; i++) {
        let Sr_No = $(
          `#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr:nth-child(${i}) > td:nth-child(1)`
        )
          .text()
          .trim()
        let Document_No = $(
          `#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr:nth-child(${i}) > td:nth-child(2)`
        )
          .text()
          .trim()
        let Date_of_Receiving = $(
          `#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr:nth-child(${i}) > td:nth-child(3)`
        )
          .text()
          .trim()
        let Filed_by = $(
          `#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr:nth-child(${i}) > td:nth-child(4)`
        )
          .text()
          .trim()
        let Name_of_Advocate = $(
          `#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr:nth-child(${i}) > td:nth-child(5)`
        )
          .text()
          .trim()
        let Document_Filed = $(
          `#secondpage > div:nth-child(13) > table:nth-child(20) > tbody > tr:nth-child(${i}) > td:nth-child(6)`
        )
          .text()
          .trim()

        documentDetailsObject = {
          Sr_No,
          Document_No,
          Date_of_Receiving,
          Filed_by,
          Name_of_Advocate,
          Document_Filed,
        }

        documentArray.push(documentDetailsObject)
      }

      // **** **** ****

      console.log(wpilKey)
      console.log('=============== Case Status ===================')
      console.log(caseStatus)
      console.log('========== Petitioner and Advocate ===========')
      console.log(petitionerAndAdvocate)
      console.log('========== Respondent and Advocate ===========')
      console.log(respondentAndAdvocate)
      console.log('==================== Arts ====================')
      console.log(actsArray)
      console.log('============= History Cashearing =============')
      console.log(historyCasehearing)
      console.log('=================== Order ====================')
      console.log(OrderArray)
      console.log('================== Objection =================')
      console.log(ObjectionArray)
      console.log('============== Document Details ==============')
      console.log(documentArray)
    }
  }
)
